import { shipmentDetails } from "./couriershipment.service";

export class courierDto{
    courierId:number;
    courierType:string;
    weight:number;
    price:number;
    shipmentDetails: shipmentDetails;
    constructor(){

    }
}
