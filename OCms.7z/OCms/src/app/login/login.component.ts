import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CurrentLoggedUserService } from '../current-logged-user.service';
import { Login } from '../model/Login';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userName:string;
  password:string;
  role:string;
  fname:string;
  lname:string;
  mobileno:string;
  showErrorMessage: boolean =false;
  status: string;

  constructor(private loginService:LoginService,private router:Router, private currentUser: CurrentLoggedUserService) { }

  loginForm=new FormGroup({
    uid:new FormControl('',[Validators.required]),
    pass:new FormControl('',[Validators.required])
  })

  ngOnInit(): void {}

  validate(){
    let tmpEmp:Login=new Login();
    this.loginService.findUserByUsername(this.userName,this.password).subscribe(
      data =>{
        if(data==null){
          alert('login failed');
        }
        sessionStorage.setItem("userId",data.userId);
        sessionStorage.setItem('user',this.userName);
         sessionStorage.setItem('role',this.role);
        //  sessionStorage.seItem('fName',this.fname);
        //  sessionStorage.seItem('lName',this.lname);
        //  sessionStorage.seItem('mobileno',this.mobileno);

        if("customer"=== data.role.toLowerCase()) this.router.navigate(['/customer/customerHome']);
        else if("admin" === data.role.toLowerCase()) this.router.navigate(['/admin/adminHome']);
      else if("employee" === data.role.toLowerCase()) this.router.navigate(['/employee']);
      this.currentUser.setCurrentUser(data);
      },
      (error) => {
        console.log(error.error);
        this.status="Invalid Credentials";
      });   
      
      
  }

}
