import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { CouriershipmentService } from '../couriershipment.service';
import { ShipmentDetails } from '../shipment';
import {NgForm} from '@angular/forms';
import { courierDto } from '../courier';


@Component({
  selector: 'app-addshipment',
  templateUrl:'./addshipment.component.html',
  styleUrls: ['./addshipment.component.css']
})
export class AddshipmentComponent implements OnInit {

  //shipment= new ShipmentDetails();
  @ViewChild('shipmentForm')public resetDetails:NgForm;
  shipment:ShipmentDetails= new ShipmentDetails();
  courierId:any
  message:any;
  id:number;
  constructor(private service:CouriershipmentService) { }

  ngOnInit(): void {

  }
/**
 * addShipmenttocourier
 */
// public addShipmenttocourier() {
//   let resp=this.service.addShipmenttocourier(this.id,this.shipment);
//   resp.subscribe((data)=>this.message=data)
  
// }
  /**
   * name
   */
  public addNow() {
   let resp= this.service.addShipment(this.shipment);
   resp.subscribe(data=>{
   if(data==null){
     alert("add required fields");
  }
   this.message=data;
   this.resetDetails.reset();

  });
  }
}
