import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CurrentLoggedUserService } from '../current-logged-user.service';
import { Courier, LocationsDto, MyserviceService } from '../myservice.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-courier',
  templateUrl: './add-courier.component.html',
  styleUrls: ['./add-courier.component.css']
})
export class AddCourierComponent implements OnInit {

  message: any;
  LocationsDto: LocationsDto[];
  trainees: Courier[];
  login_id: number;
  status: string;
  constructor(private myservice: MyserviceService,private currentUser: CurrentLoggedUserService,private router: Router) { 
    this.login_id=this.currentUser.getCurrentUser().userId;
    console.log(this.login_id);
  }

  

  ngOnInit(): any {
    this.myservice.getLocations().subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }
  handleSuccessfulResponse(response) {
    this.LocationsDto = response;
  }
  onSubmit(addtra:Courier):any{
    console.log(addtra);
    this.myservice.sharedId=addtra.courierId;
     this.myservice.addCourier(this.currentUser.getCurrentUser().userId,addtra).subscribe(data => {
      this.message=Swal.fire("Thank You!", "Your Courier Added Successfully!", "success"),
       this.router.navigate(['/customer/listcouriers']);
    
     }, (error)=>{
        this.status="Locations Invalid";
      });
     
  }

}
