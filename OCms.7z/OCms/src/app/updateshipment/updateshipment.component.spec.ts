import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateshipmentComponent } from './updateshipment.component';

describe('UpdateshipmentComponent', () => {
  let component: UpdateshipmentComponent;
  let fixture: ComponentFixture<UpdateshipmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateshipmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateshipmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
