import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CouriershipmentService } from '../couriershipment.service';
import { MyserviceService } from '../myservice.service';
import { ShipmentDetails } from '../shipment';

@Component({
  selector: 'app-updateshipment',
  templateUrl: './updateshipment.component.html',
  styleUrls: ['./updateshipment.component.css']
})
export class UpdateshipmentComponent implements OnInit {
  id: number;
  shipment: any;
  message:any;
  constructor(private service: CouriershipmentService,private myservice: MyserviceService,private route: ActivatedRoute,private router: Router,) { }

  ngOnInit(): void {
    this.shipment=this.myservice.shareObject;
    this.id= this.route.snapshot.params['id'];
  }
  UpdateshipmentComponent(ship:ShipmentDetails) {
    this.service.updateShipment(this.id,ship)
      .subscribe(data =>{
      this.message=data;
    this.gotoList()} );
    
  }
  onSubmit(ship:ShipmentDetails) {
    this.UpdateshipmentComponent(ship);   
    alert("Shipment updated successfully"); 
  }
  gotoList() {
   
      this.router.navigate(['employee/search']);
    
  }


}
