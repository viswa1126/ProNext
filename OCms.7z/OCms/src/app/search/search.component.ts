import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService, Office } from '../myservice.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  offices: Office;
  office_id:number;
  office_name: any;
  office_place: string;
  office_address: string;
  id:any;
  message: string;

  constructor(private myservice: MyserviceService, private router: Router) { }

  ngOnInit(): void {
    this.id=this.myservice.sharedId;
    this.myservice.getOffice(this.id).subscribe(
      offices => {
        this.offices = offices;
        this.office_name=this.offices.office_name; 
        this.office_place=this.offices.office_place; 
        this.office_address=this.offices.office_address;
      });
  }
  update(updateoffice: Office) {
    this.myservice.update(updateoffice);
    this.router.navigate(['/admin/updateoffice']); //updating the employee
  }
  delete(deleteoffice: Office): any {
    this.myservice.delete(deleteoffice.office_id).subscribe(data => {
      this.message = data
    });
    this.router.navigate(['/listoffice']);
  }

}
