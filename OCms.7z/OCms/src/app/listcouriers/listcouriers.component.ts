import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CouriershipmentService } from '../couriershipment.service';
import { CurrentLoggedUserService } from '../current-logged-user.service';
import { Courier, MyserviceService } from '../myservice.service';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-listcouriers',
  templateUrl: './listcouriers.component.html',
  styleUrls: ['./listcouriers.component.css']
})
export class ListcouriersComponent implements OnInit {
  p: number = 1;
  count: number = 5;
  message: any;
 courier: Courier[];

  constructor(private myservice: MyserviceService, private currentUser: CurrentLoggedUserService, private router: Router, 
    private service:CouriershipmentService) {
  }
 
  ngOnInit(): any {
    this.myservice.getCouriersById(this.currentUser.getCurrentUser().userId).subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }
  handleSuccessfulResponse(response) {
    this.courier= response;
  }
  updateC(updateoffice: Courier) {
    this.myservice.updateC(updateoffice);
    this.router.navigate(['/customer/updatecourier']); //updating the employee
  }


  
reloadData() {
  this.service.getCouriersById(this.currentUser.getCurrentUser().userId)
  .subscribe(data=>{console.log(data);
    
  },
  error => console.log(error));
 
 
}
    deleteCourier(DeleteCourier: Courier): any {
   Swal.fire({
  title: 'Are you sure?',
  text: 'You will not be able to recover this courier Back..!',
  icon: 'warning',
  showCancelButton: true,
  confirmButtonText: 'Yes, delete it!',
  cancelButtonText: 'No, keep it'
}).then((result) => {
  if (result.value) {
    this.myservice.deleteCourier(DeleteCourier.courierId).subscribe(data => {this.message =
    Swal.fire(
      'Deleted!',
      'Your Courier has been deleted.',
      'success'
    )
    this.myservice.getCouriersById(this.currentUser.getCurrentUser().userId).subscribe(
      response => this.handleSuccessfulResponse(response));
  }
  
  )
}
  else if (result.dismiss === Swal.DismissReason.cancel) {
    Swal.fire(
      'Cancelled',
      'Your courier is safe :)',
      'error'
    )
  }
})
this.myservice.getCouriersById(this.currentUser.getCurrentUser().userId).subscribe(
  response => this.handleSuccessfulResponse(response));
}

  getCouriersById(id:number){
    this.service.getCouriersById(id).subscribe(data=>{
      if(data!=null)
      {
        this.router.navigate(['customer/getcourier',id]);
      }
      else{
        this.message=Swal.fire("Your Shipment details are not Processed still,You can track details after 1 day");
        
      }
    })
    
  }

}
