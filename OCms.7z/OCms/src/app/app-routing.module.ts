import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutApplComponent } from './about-appl/about-appl.component';
import { AddCourierComponent } from './add-courier/add-courier.component';
import { AddaccountComponent } from './addoffice/addoffice.component';
import { AddshipmentComponent } from './addshipment/addshipment.component';
import { AddshipmentcourierComponent } from './addshipmentcourier/addshipmentcourier.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminComponent } from './admin/admin.component';
import { AuthGuard } from './authguard';
import { BasichomeComponent } from './basichome/basichome.component';
import { CourierDtoComponent } from './courier-dto/courier-dto.component';
import { CourierSearchComponent } from './courier-search/courier-search.component';
import { CustomerHomeComponent } from './customer-home/customer-home.component';
import { CustomerComponent } from './customer/customer.component';
import { EmployeeComponent } from './employee/employee.component';
import { ListEmployeeComponent } from './list-offices/list-offices.component';
import { ListcouriersComponent } from './listcouriers/listcouriers.component';
import { LoginComponent } from './login/login.component';
import { SearchDeleteComponent } from './search-delete/search-delete.component';
import { SearchComponent } from './search/search.component';

import { SignUpComponent } from './sign-up/sign-up.component';
import { TrackcourierComponent } from './trackcourier/trackcourier.component';
import { UpdateEmployeeComponent } from './update-office/update-office.component';
import { UpdatecourierComponent } from './updatecourier/updatecourier.component';
import { UpdateloginComponent } from './updatelogin/updatelogin.component';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';
import { UpdateshipmentComponent } from './updateshipment/updateshipment.component';

import { ViewloginComponent } from './viewlogin/viewlogin.component';


const routes: Routes = [{
  path:'',
  component:BasichomeComponent
},
{
  path:'signup',
  component:SignUpComponent
},
{
  path:'login',
  component:LoginComponent
},
{
  path:'aboutapp',
  component:AboutApplComponent
},

{
  path:'admin',
  component:AdminComponent,
  children: [
    {path: 'addoffice', component:AddaccountComponent },
    {path: 'listoffice', component: ListEmployeeComponent},
    {path:'updateoffice',component:UpdateEmployeeComponent},
    {path:'findAll', component:ViewloginComponent},
    {path:'UpdateloginComponent', component:UpdateloginComponent},
    {path:'search',component:SearchComponent},
    {path:'adminHome',component:AdminHomeComponent}
  ]
},
{
  path:'customer',
  canActivate:[AuthGuard],
  component:CustomerComponent,
  children:[
    {path:'add-courier',component:AddCourierComponent},
    {path:'listcouriers',component:ListcouriersComponent},
    {path:'updatecourier',component:UpdatecourierComponent},
    {path:'updateprofile',component:UpdateprofileComponent},
    {path:'trackcourier',component:TrackcourierComponent},
    {path:"getcourier/:id",component:TrackcourierComponent},
    {path:"customerHome",component:CustomerHomeComponent}
  
  ]

},
{
  path:'employee',
  component:EmployeeComponent,
  children:[
    //{path:"",redirectTo:"shipment/addshipment",pathMatch:"full"}, 
   {path:"addshipmentcourier/:id",component:CourierDtoComponent},
   {path:"shipment/addshipment",component:AddshipmentComponent},
   {path:"updateshipmentdetails/:id",component:UpdateshipmentComponent},
   {path:"search",component:SearchDeleteComponent},
   {path:"trackcourier",component:CourierSearchComponent},
   {path:"getcourier/:id",component:TrackcourierComponent},
   {path:"addshipcourier/:id",component:AddshipmentcourierComponent},
   {path:'updateprofile',component:UpdateprofileComponent}
   
  ]

}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
