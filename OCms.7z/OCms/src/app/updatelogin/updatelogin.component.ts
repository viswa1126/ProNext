import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { Login } from '../model/Login';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-updatelogin',
  templateUrl: './updatelogin.component.html',
  styleUrls: ['./updatelogin.component.css']
})
export class UpdateloginComponent implements OnInit {
 
  login: any;
  message:any;
  constructor(private service: LoginService,private router: Router) { }

  ngOnInit(): void {
  }
  UpdateloginComponent() {
    this.service.updateDetails(this.login)
      .subscribe(data =>{
      this.login=new Login();
      this.message=data;
      this.gotoList()} );
    
  }
  onSubmit() {
    this.UpdateloginComponent();  
  }
  gotoList() {
    this.router.navigate(['/admin/findAll']);   
  }
}
