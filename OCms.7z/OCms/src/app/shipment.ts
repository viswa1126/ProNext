
export class ShipmentDetails{
        shipmentId:number;
        shipmentType:string;
        shipmentDetails:string;
        date:string;
        cost:number;
        time:string;
       status:string;
       courierdto:courierDto;
    constructor(
       
    ){
        // this.courierId=courierId;
        // this.date=date;
        // this.cost=cost;
        // this.shipmentDetails=shipmentDetails;
        // this.shipmentType=shipmentType
    }
}

export class courierDto{
    courierId:number;
    CourierType:string;
    weight:number;
    price:number;
  }