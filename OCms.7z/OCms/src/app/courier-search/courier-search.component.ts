import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import { courierDto } from '../courier';
import { CourierserviceService } from '../courierservice.service';
import { CouriershipmentService } from '../couriershipment.service';
import { MyserviceService } from '../myservice.service';
import { ShipmentDetails } from '../shipment';

@Component({
  selector: 'app-courier-search',
  templateUrl: './courier-search.component.html',
  styleUrls: ['./courier-search.component.css']
})
export class CourierSearchComponent implements OnInit {
id:number;
shipment:any;
 // shipment: ShipmentDetails[];
  courier:courierDto[];
  p: number = 1;
  count: number = 5;
  active: import("c:/Users/pc/Downloads/Ocms frontend/Ocms frontend/src/app/myservice.service").Courier;
  message: Promise<import("sweetalert2").SweetAlertResult<any>>;
  constructor(private myservice: MyserviceService,private service:CourierserviceService,private router: Router,private route: ActivatedRoute) { }


  ngOnInit(): any {​​​​​
    // this.id= this.route.snapshot.params['id'];
     this.shipment=new ShipmentDetails();
    this.service.getcourier().subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }​​​​​
  handleSuccessfulResponse(response) {​​​​​
    this.courier= response;
    console.log(this.courier)
  }​​​​​
  
  reloadData() {
    this.service.getcourier()
    .subscribe(data=>{console.log(data);
      
    },
    error => console.log(error));
   
   
  }
  addcourier(id:number) {
    this.service.getShipmentsById(id).subscribe(data=>
      {
        console.log(data);
        if(data!=null)
        {
          //alert("Shipment already exists for this courier,Please check track courier for shipment details of Courier Id: "+id);
          this.message=Swal.fire("Shipment already exists,Please check track courier for shipment details of Courier Id: "+id);
        }
        else{
          this.router.navigate(['employee/addshipcourier',id]);
        }
      })
  }

  getCouriersById(id:number){
    this.router.navigate(['employee/getcourier',id]);
  }

}
