import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { CouriershipmentService } from '../couriershipment.service';
import { ShipmentDetails } from '../shipment';

@Component({
  selector: 'app-courier-dto',
  templateUrl: './courier-dto.component.html',
  styleUrls: ['./courier-dto.component.css']
})

export class CourierDtoComponent implements OnInit {
shipment:any;
courierId:any;
id:number;
message:any;
  constructor(private service:CouriershipmentService,private route: ActivatedRoute,private router: Router) {
    
   }

  ngOnInit(): void {
    this.courierId= this.route.snapshot.params['id'];
    this.shipment=new ShipmentDetails();
   
  }


 onSubmit(add:ShipmentDetails):any {
    console.log(add);
    

    let resp=this.service.addshipmentcourier(this.courierId,add);
    resp.subscribe((data)=>this.message=data)
    
  }
  

}
