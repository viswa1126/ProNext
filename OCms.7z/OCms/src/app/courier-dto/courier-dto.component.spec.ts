import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CourierDtoComponent } from './courier-dto.component';

describe('CourierDtoComponent', () => {
  let component: CourierDtoComponent;
  let fixture: ComponentFixture<CourierDtoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CourierDtoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CourierDtoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
