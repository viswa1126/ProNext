import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutApplComponent } from './about-appl.component';

describe('AboutApplComponent', () => {
  let component: AboutApplComponent;
  let fixture: ComponentFixture<AboutApplComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutApplComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutApplComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
