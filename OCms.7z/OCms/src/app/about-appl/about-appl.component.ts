import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-appl',
  templateUrl: './about-appl.component.html',
  styleUrls: ['./about-appl.component.css']
})
export class AboutApplComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
