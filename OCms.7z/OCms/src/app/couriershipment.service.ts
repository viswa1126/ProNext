import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ShipmentDetails } from './shipment';

@Injectable({
  providedIn: 'root'
})
export class CouriershipmentService {
  private baseUrl = 'http://localhost:8010/shipment';
  private courierUrl='http://localhost:8010/courier';
  
  constructor( private http:HttpClient) { }


  /**
   * name
   */
  public getCouriersById(id:number) {
    console.log("ins service get couriers by id");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.http.get<any>("http://localhost:8010/courier/getShipmentDetailsByCourierId/"+id);
   
  }
  public sharedId={};



  public trackcourier(id:number){
    return this.http.get("http://localhost:8010/shipment/trackstatus/"+id);
  }
    
  
  public getByCourierId(id:number){
    return this.http.get("http://localhost:8010/courier/trackcourier/"+id);
  }
    

  /**
   * addShipment
   */
  public addShipment(shipment) {
    return this.http.post("http://localhost:8010/shipment/addshipment",shipment,
    {responseType:"text" as "json"})
  }


  /**
   * addShipmenttocourier
   */
  public addshipmentcourier(id:number,add:ShipmentDetails):Observable <object> {
    return this.http.post("http://localhost:8010/courier/addshipment/"+id,add);

    
  }
 
  /**
   * getShipments
   */
  public getShipments():any{

    return this.http.get("http://localhost:8010/shipment/showShipmentDetails");
 

    
  }
  
  deleteShipmentDetails(id: number): Observable<any> {
   
    return this.http.delete(`${this.baseUrl}/deleteShipment/${id}`, { responseType: 'text' });
  }
  /**
   * name
   */
  /**
   * updateShipment
id:number,value:any   */
  public updateShipment(id:number,value:any):Observable<Object>{
    return this.http.put(`${this.baseUrl}/updateshipmentdetails/${id}`, value);
  }


}

export class shipmentDetails{
  shipmentId:number;
  shipmentType:string;
  shipmentDetails:string;
  date:string;
  time:string;
  cost:number;
}



export class courierDto{
  courierId:number;
  CourierType:string;
  weight:number;
  price:number;
}