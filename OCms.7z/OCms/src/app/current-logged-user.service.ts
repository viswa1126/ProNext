import { Injectable } from '@angular/core';
import { Login } from './model/Login';



@Injectable({
  providedIn: 'root'
})
export class CurrentLoggedUserService {

  currentUser: Login;

  constructor() {

  }

  public setCurrentUser(userdto: Login) {
    this.currentUser = userdto;
  }

  public getCurrentUser() {
    return this.currentUser;
  }
}
