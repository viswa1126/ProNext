import { TestBed } from '@angular/core/testing';

import { CouriershipmentService } from './couriershipment.service';

describe('CouriershipmentService', () => {
  let service: CouriershipmentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CouriershipmentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
