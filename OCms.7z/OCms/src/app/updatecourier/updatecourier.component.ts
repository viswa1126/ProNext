import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CurrentLoggedUserService } from '../current-logged-user.service';
import { Courier, LocationsDto, MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-updatecourier',
  templateUrl: './updatecourier.component.html',
  styleUrls: ['./updatecourier.component.css']
})
export class UpdatecourierComponent implements OnInit {
  message: void;
  LocationsDto: LocationsDto[];
  trainees: Courier[];
  login_id:number;
  obj:any;
  
  constructor(private myservice: MyserviceService,private currentUser: CurrentLoggedUserService,private router: Router) { 
    this.login_id=this.currentUser.getCurrentUser().userId;
    this.obj=this.myservice.update1();
  }

  ngOnInit(): any {
    this.myservice.getLocations().subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }
  handleSuccessfulResponse(response) {
    this.LocationsDto = response;
  }
  onSubmit(update:Courier):any{
    console.log(update);
    this.myservice.sharedId=update.courierId;
     this.myservice.UpdateCourier(update).subscribe(data => {
      this.message=alert("Courier updated Successfully")});
      this.router.navigate(['/customer/listcouriers']);
  }
}
