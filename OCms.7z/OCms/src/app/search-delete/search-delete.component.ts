import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import Swal from 'sweetalert2';
import { courierDto } from '../courier';
import { CouriershipmentService } from '../couriershipment.service';
import { MyserviceService, Office } from '../myservice.service';
import { ShipmentDetails } from '../shipment';

@Component({
  selector: 'app-search-delete',
  templateUrl: './search-delete.component.html',
  styleUrls: ['./search-delete.component.css']
})
export class SearchDeleteComponent implements OnInit {
  //POSTS: any;
  p: number = 1;
  count: number = 5;


  //shipments: any[]=[];
  // ShipmentDetails:any;
   shipment: ShipmentDetails[];
   shipmentId:number;
  message: any;

//shipment:[]=[];
  constructor(private service:CouriershipmentService,private myservice: MyserviceService,private router: Router) { }

//   ngOnInit(): any {
    
//     this.reloadData();
// }


ngOnInit(): any {​​​​​
  this.service.getShipments().subscribe(
    response => this.handleSuccessfulResponse(response),
  );
}​​​​​
handleSuccessfulResponse(response) {​​​​​
  this.shipment= response;
  console.log(this.shipment)
}​



reloadData() {
  this.service.getShipments()
  .subscribe(data=>{console.log(data);
    
  },
  error => console.log(error));
 
 
}

addshipmenttocourier(id:number){
  this.router.navigate(['employee/addshipmenttocourier',id]);
}
updateshipment(id:number,shipment:ShipmentDetails){
  this.myservice.shareObject=shipment;
  this.router.navigate(['employee/updateshipmentdetails',id]);
}

deleteShipmentDetails(id: number) {
  Swal.fire({
    title: 'Are you sure?',
    text: 'You will not be able to recover this courier Back..!',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, delete it!',
    cancelButtonText: 'No, keep it'
  }).then((result) => {
    if (result.value) {
      this.service.deleteShipmentDetails(id).subscribe( data => {this.message=
      Swal.fire(
        'Deleted!',
        'Your Courier has been deleted.',
        'success'
      )
      this.service.getShipments().subscribe(
        response => this.handleSuccessfulResponse(response));
    }
    
    )
  }
  else if (result.dismiss === Swal.DismissReason.cancel) {
    Swal.fire(
      'Cancelled',
      'Your courier is safe :)',
      'error'
    )
  }
})   
}
// findShipment(id:number){
//   this.service.getCouriersById(id).subscribe(
//     data => {
//       console.log(data);
//         response => this.handleSuccessfulResponse(response);
//         this.router.navigate(['/employee/findshipment']);
//     },
//     error => console.log(error));
// }
 
}