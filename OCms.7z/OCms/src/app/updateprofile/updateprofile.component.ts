import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CurrentLoggedUserService } from '../current-logged-user.service';
import { Login } from '../model/Login';
import { Courier, LocationsDto, MyserviceService } from '../myservice.service';
import { LoginService } from '../services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-updateprofile',
  templateUrl: './updateprofile.component.html',
  styleUrls: ['./updateprofile.component.css']
})
export class UpdateprofileComponent implements OnInit {
  message: any;
  LocationsDto: LocationsDto[];
  trainees: Courier[];
  userId:number;
  userName:string;
  fName:string;
  lName:string;
  phoneNumber:number;
  
  constructor(private myservice: MyserviceService,private currentUser: CurrentLoggedUserService,private router: Router) { 
   
  }

  ngOnInit(): any {
    this.userId=this.currentUser.getCurrentUser().userId;
    this.userName=this.currentUser.getCurrentUser().userName;
    this.fName=this.currentUser.getCurrentUser().fName;
    this.lName=this.currentUser.getCurrentUser().lName;
    this.phoneNumber=this.currentUser.getCurrentUser().phoneNumber;
  }
  
  onSubmit(addtra:Login):any{
    console.log(addtra);
     this.myservice.UpdateProfile(addtra).subscribe(data => {
      this.message=Swal.fire("Your Profile Updated Successfully!")});
      this.router.navigate(['/employee']);
  }

}
