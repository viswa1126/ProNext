import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from '../model/Login';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-viewlogin',
  templateUrl: './viewlogin.component.html',
  styleUrls: ['./viewlogin.component.css']
})
export class ViewloginComponent implements OnInit {
  p: number = 1;
  count: number = 5;
  message: any;
  logins: Login[];
  //login: Login;
  constructor(private myservice: LoginService, private router: Router) {
  }

  ngOnInit(): any {
    this.myservice.findAll().subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }
  handleSuccessfulResponse(response) {
    this.logins= response;
  }
  
  // update(login:Login) {
  //   this.myservice.updateDetails(login)
  //     .subscribe(data =>{
  //     //this.login=new Login();
  //     this.message=data;
  //     this.gotoList()} );
    
  // }
  // gotoList() {
  //   this.router.navigate(['admin/UpdateloginComponent']);   
  // }
 
  delete(deletelogin: Login): any {
    this.myservice.deleteLogin(deletelogin.userId).subscribe(data => {
      this.message = data
    });
    this.router.navigate(['admin/findAll']);
  }

}
