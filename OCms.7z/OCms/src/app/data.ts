import { shipmentDetails } from "./couriershipment.service";

export class Shipcourier{
    courierId:number;
    CourierType:string;
    weight:number;
    price:number;
    shipmentDetailss: shipmentDetails[] = [];
}