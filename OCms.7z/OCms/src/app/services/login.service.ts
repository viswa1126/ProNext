import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Office } from '../myservice.service';
import { Login } from '../model/Login';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  loginUrl="http://localhost:8002/login/findAll"
 

  constructor(private http: HttpClient) { }

  findUserByUsername(tmpUsername:string,tmpPassword:string):Observable<any>{
    console.log("In service of find by username " +tmpUsername+" and password "+tmpPassword);
    return this.http.get('http://localhost:8010/login/'+tmpUsername+"/"+tmpPassword);
  }

  signUp(login){
    return this.http.post("http://localhost:8010/signup",login);
  }
  addoffice(office:Office){
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');  
    return this.http.post("http://localhost:8010/OfficeManagement/addOffice", office,{ headers, responseType: 'text'});
  }
  findAll(){
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.http.get<Login>("http://localhost:8010/login/findAll");
  }
 updateDetails(login:Login){
   return this.http.put("http://localhost:8010/login/update", login);
 }
 public deleteLogin(id:number){
   return this.http.delete("http://localhost:8010/DeleteLogin/" + id);
 }
}
