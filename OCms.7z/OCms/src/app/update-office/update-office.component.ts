import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService, Office} from '../myservice.service';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-office.component.html',
  styleUrls: ['./update-office.component.css']
})
export class UpdateEmployeeComponent implements OnInit {
  obj1: any;
  employees: Office[];
  message: string;
  constructor(private myservice: MyserviceService, private router: Router) {
    this.obj1 = this.myservice.updateMethod();
  }
  onUpdate(office: Office): any {
    return this.myservice.onUpdate(office.office_id,office).subscribe(data => {
      //this.message = data;
        this.message="Office Details are updated";
        this.router.navigate(['/admin/listoffice']);
    });
  }
  ngOnInit(): void {
  }

}
