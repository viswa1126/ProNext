import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CourierserviceService {

 
  private baseUrl = 'http://localhost:8010/shipment';
  private baseUrl1='http://localhost:8010/courier';
  constructor( private http:HttpClient) { }



    /**
   * addShipmenttocourier
   */
  public addShipmenttocourier(id:number,shipment:any):Observable <object> {
    return this.http.post(`${this.baseUrl1}/addshipmenttocourier/${id}`,shipment)

    
  }
  public getcourier():any{

    return this.http.get("http://localhost:8010/courier/showcourier"); 
  }

  public getShipmentsById(id:number):any{

    return this.http.get("http://localhost:8010/courier/getShipmentDetailsByCourierId/"+id);
 

    
  }
}
