import { Component, OnInit } from '@angular/core';
import { Courier, MyserviceService, Office } from '../myservice.service';
import { Router, RouterLink } from '@angular/router';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-list-employee',
  templateUrl: './list-offices.component.html',
  styleUrls: ['./list-offices.component.css']
})
export class ListEmployeeComponent implements OnInit {
  message: any;
  offices: Office[];
  office_id:number;
  p: number = 1;
  count: number = 5;
  constructor(private myservice: MyserviceService, private router: Router) {
  }

  ngOnInit(): any {
    this.myservice.getOffices().subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }
  handleSuccessfulResponse(response) {
    this.offices= response;
  }
  

    
reloadData() {
  this.myservice.getOffices()
  .subscribe(data=>{console.log(data);
  },
  error => console.log(error));
}
  
  update(updateoffice: Office) {
    this.myservice.update(updateoffice);
    this.router.navigate(['/admin/updateoffice']); //updating the employee
  }

  delete(deleteoffice: Office): any {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this courier Back..!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        this.myservice.delete(deleteoffice.office_id).subscribe(data => {this.message =
        Swal.fire(
          'Deleted!',
          'Your Courier has been deleted.',
          'success'
        )
        this.myservice.getOffices().subscribe(
          response => this.handleSuccessfulResponse(response)
        );
      }
      
      )
    }
    else if (result.dismiss === Swal.DismissReason.cancel) {
      Swal.fire(
        'Cancelled',
        'Your courier is safe :)',
        'error'
      )
    }
  })   
  }
  getOffice(id:number){
    this.myservice.sharedId=id; 
     this.router.navigate(['/admin/search']);
   }
}
