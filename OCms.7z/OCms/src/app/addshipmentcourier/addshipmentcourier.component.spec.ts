import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddshipmentcourierComponent } from './addshipmentcourier.component';

describe('AddshipmentcourierComponent', () => {
  let component: AddshipmentcourierComponent;
  let fixture: ComponentFixture<AddshipmentcourierComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddshipmentcourierComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddshipmentcourierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
