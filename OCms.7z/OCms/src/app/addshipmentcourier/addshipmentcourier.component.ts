import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CouriershipmentService } from '../couriershipment.service';
import { ShipmentDetails } from '../shipment';

@Component({
  selector: 'app-addshipmentcourier',
  templateUrl: './addshipmentcourier.component.html',
  styleUrls: ['./addshipmentcourier.component.css']
})
export class AddshipmentcourierComponent implements OnInit {
  shipment:any;
  courierId:any;
  id:number;
  message:any;
  status: string;
  constructor(private service:CouriershipmentService,private route: ActivatedRoute,private router: Router) { }

  ngOnInit(): void {
    this.courierId= this.route.snapshot.params['id'];
    this.shipment=new ShipmentDetails();
   
  }
  onSubmit(add:ShipmentDetails):any {
    console.log(add);
    
    

    let resp=this.service.addshipmentcourier(this.courierId,add);
    resp.subscribe((data)=>{
      this.message=data;
    },
    error=>{
      this.status="Shipment already added for this courier";
    })
    alert("Shipment added successfully");
  
  }
  

}
