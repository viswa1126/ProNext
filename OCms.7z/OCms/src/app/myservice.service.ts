import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { logging } from 'protractor';
import { LoginComponent } from './login/login.component';
import { Login } from './model/Login';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  updateCou: Courier;
  updateoffice: Office;
  constructor(private http: HttpClient) { }

  public getOffices() {
    console.log("ins service get employees");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.http.get<Office>("http://localhost:8010/OfficeManagement/ListAllOffices");
  }
  public delete(id: number) {
    console.log("ins service delete");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.http.delete("http://localhost:8010/OfficeManagement/DeleteOffice/" + id,  { headers, responseType: 'text'});
  }
  public update(update:Office) {
    this.updateoffice = update;
  }
  public updateMethod() {
    return this.updateoffice;
  }
  public onUpdate(id:number,update: Office) {
    console.log("ins service update");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.http.put("http://localhost:8010/OfficeManagement/UpdateOffice/"+ id, update,  { headers, responseType: 'text'});
  }
  public getLocations() {
    console.log("ins service get locations");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.http.get<LocationsDto>("http://localhost:8010/courier/ListAllLocations");
  }
  public addCourier(id:number,addtra: Courier) {
    console.log("ins service add");
    console.log(addtra);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.http.post("http://localhost:8010/courier/addcourier/"+ id, addtra,  { headers, responseType: 'text'});
  }

  public UpdateCourier(addtra: Courier) {
    console.log("ins service update");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.http.put("http://localhost:8010/courier/updatecourier", addtra,  { headers, responseType: 'text'});
  }

  public UpdateProfile(addtra:Login) {
    console.log("ins service update");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.http.put("http://localhost:8010/login/update", addtra,  { headers, responseType: 'text'});
  }

  public getCouriers() {
    console.log("ins service get employees");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.http.get<Courier>("http://localhost:8010/courier/ListAllCouriers");
  }

  public getCouriersById(id:number) {
    console.log("ins service get employees");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.http.get<Courier>("http://localhost:8010/courier/ListAllCourierById/"+id);
  }

   public deleteCourier(id:number) {
    console.log("ins service delete");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.http.delete("http://localhost:8010/courier/deletecourier/"+id);
  }
  public getOffice(id:number):Observable<Office>{
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.http.get<Office>("http://localhost:8010/OfficeManagement/GetOfficeById/"+id);
  }
  public updateC(updateC:Courier) {
    this.updateCou = updateC;
  }
  public update1() {
    return this.updateCou;
  }
  public sharedId={};

  public shareObject={};
}
  export class Office{
    office_id:number;
    office_name:string;
    office_address:string;
    office_place:string;  
  
  }
  export class Courier{
    courier_id(courier_id: any) {
      throw new Error('Method not implemented.');
    }
    courierId:number;
   courierType:string;
    pickupAddress: string;
   deliveryAddress: string;
	  weight:number;
    price:number;
     login:Login;
     
  
  }
  export class LocationsDto{
    LocatioId:number;
    LocationName:number;
  }
