import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { LoginComponent } from './login/login.component';

import { BasichomeComponent } from './basichome/basichome.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { LoginService } from './services/login.service';
import { AppRoutingModule } from './app-routing.module';
import { CustomerComponent } from './customer/customer.component';
import { AdminComponent } from './admin/admin.component';
import { EmployeeComponent } from './employee/employee.component';
import { AddaccountComponent } from './addoffice/addoffice.component';
import { ListEmployeeComponent } from './list-offices/list-offices.component';
import { UpdateEmployeeComponent } from './update-office/update-office.component';
import { ViewloginComponent } from './viewlogin/viewlogin.component';
import { UpdateloginComponent } from './updatelogin/updatelogin.component';

import { AddCourierComponent } from './add-courier/add-courier.component';
import { ListcouriersComponent } from './listcouriers/listcouriers.component';
import { UpdatecourierComponent } from './updatecourier/updatecourier.component';
import { AboutApplComponent } from './about-appl/about-appl.component';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';
import { AddshipmentComponent} from './addshipment/addshipment.component';
import { UpdateshipmentComponent } from './updateshipment/updateshipment.component';
import { AddshipmentcourierComponent } from './addshipmentcourier/addshipmentcourier.component';
import { CourierSearchComponent } from './courier-search/courier-search.component';
import { SearchDeleteComponent } from './search-delete/search-delete.component';
import { TrackcourierComponent } from './trackcourier/trackcourier.component';
import { CourierDtoComponent } from './courier-dto/courier-dto.component';
import{NgxPaginationModule}from 'ngx-pagination';
import { SearchComponent } from './search/search.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { CustomerHomeComponent } from './customer-home/customer-home.component';
import { HttpClient } from '@angular/common/http';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignUpComponent,
    BasichomeComponent,
    CustomerComponent,
    AdminComponent,
    EmployeeComponent,
    AddaccountComponent,
    ListEmployeeComponent,
    UpdateEmployeeComponent,
    ViewloginComponent,
    UpdateloginComponent,
    ListcouriersComponent,
    AddCourierComponent,
    ListcouriersComponent,
    UpdatecourierComponent,
    AboutApplComponent,
    UpdateprofileComponent,
    AddshipmentComponent,
    SearchDeleteComponent,
    UpdateshipmentComponent,
    CourierDtoComponent,
    CourierSearchComponent,
    TrackcourierComponent,
    AddshipmentcourierComponent,
    SearchComponent,
    AdminHomeComponent,
    CustomerHomeComponent
  
  
  ],
  imports: [BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxPaginationModule,
    FormsModule,
    HttpClientModule,
    
  
  ],
  providers: [LoginService,HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
