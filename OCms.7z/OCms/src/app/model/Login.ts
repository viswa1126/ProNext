export class Login{
    userId:number;
    fName:string;
    lName:string;
    userName:string;
    password:string;
    role:string;   
    phoneNumber:number;
}