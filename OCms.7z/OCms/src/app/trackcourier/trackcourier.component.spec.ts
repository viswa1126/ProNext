import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrackcourierComponent } from './trackcourier.component';

describe('TrackcourierComponent', () => {
  let component: TrackcourierComponent;
  let fixture: ComponentFixture<TrackcourierComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrackcourierComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TrackcourierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
