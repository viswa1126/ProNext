import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
// import { courierDto } from '../courier';
import { courierDto, CouriershipmentService, shipmentDetails } from '../couriershipment.service';
import { ShipmentDetails } from '../shipment';

@Component({
  selector: 'app-trackcourier',
  templateUrl: './trackcourier.component.html',
  styleUrls: ['./trackcourier.component.css']
})
export class TrackcourierComponent implements OnInit {
  courierId:any;
courier:courierDto;
shipment:ShipmentDetails;
  message: any;
//shipment:any
 // shipment: ShipmentDetails[];
  constructor(private service:CouriershipmentService ,private route: ActivatedRoute, private router: Router) { }

  name = 'Status';
orderStatus:any;
  //Demo purpose only, Data might come from Api calls/service
  public counts = ["New","Inprogress","outfordelivery",
  "delivered"];

  
  ngOnInit(): void {
   this.courier= new courierDto();
    this.courierId= this.route.snapshot.params['id'];
    this.service.getByCourierId(this.courierId).subscribe(
      response=>this.handleSuccessfulResponse1(response))
    this.orderStatus= this.service.trackcourier(this.courierId).subscribe(data=>console.log("trackstatus"+data)) ;
    this.service.getCouriersById(this.courierId).subscribe(
      response => this.handleSuccessfulResponse(response),
     
    )
  }
  handleSuccessfulResponse(response) {
    this.shipment= response;
    console.log(this.shipment);
  }
  handleSuccessfulResponse1(response) {
    this.courier= response;
    console.log(this.courier);
  }


getCouriersById(id:number){
  this.router.navigate(['customer/getcourier',id]);
}
}
