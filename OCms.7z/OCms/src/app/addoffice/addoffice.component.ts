import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Office } from '../myservice.service';
import { LoginService } from '../services/login.service';
import Swal from 'sweetalert2';



@Component({
  selector: 'app-addaccount',
  templateUrl: './addoffice.component.html',
  styleUrls: ['./addoffice.component.css']
})
export class AddaccountComponent implements OnInit {

  

 
  message: any;
  id:any;
  status:string;
  constructor(private loginService:LoginService,private router: Router) {

   }

  ngOnInit(): void {
      //this.id=this.myservice.sharedId;
  }
 onSubmit(office:Office):any{
    console.log(office);
     this.loginService.addoffice(office).subscribe(
         data => {
          console.log(data);
      this.message=Swal.fire("Office Added Successfully");
      this.router.navigate(['/admin/listoffice']);
     // this.myservice.sharedId=this.id;
  },
  error=>{
      this.status="Enter valid details";

  })
}
}
